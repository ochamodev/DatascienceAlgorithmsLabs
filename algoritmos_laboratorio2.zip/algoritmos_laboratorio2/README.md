# algoritmos_laboratorio2
Algoritmos en la Ciencia de Datos, Laboratorio 2
